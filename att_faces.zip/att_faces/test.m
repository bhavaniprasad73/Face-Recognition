%A=[0 2 0 2 0; 0 4 100 102 0; 0 2 4 2 0];
%B=[-1 0 1];
%c=abs(B);
%sum=0;
%n=1;
%m=1;
% %[Gmag, Gdir]=imgradient(A, 'prewitt');
%G=fspecial('prewit');
%E=imfilter(A,G);

img = imread('att.pnm');
img=imresize(img,[96,80]);
H=img(:);
Cell=mat2cell(img,[8 8 8 8 8 8 8 8 8 8 8 8],[8 8 8 8 8 8 8 8 8 8]);
%E = blockproc(img, [16, 16], fun, 'BorderSize', [1, 1])
%img=rgb2gray(img);
%imageinfo('att.pnm');
%ImageCells=mat2tiles(img,[16,16]);
fun = @(block) mean(mean(block.data));
im4 = blockproc(img,[16 16],fun,'BorderSize',[1 1],'TrimBorder',false);
im5 = blockproc(img,[16 16],fun);
T = blockproc(img,[16, 16], fun, 'BorderSize', [8, 8],'TrimBorder',false);
[a b]=size(img);
 for i=1:a-9
    for j=1:b-11

        BLOCK=img(i:i+9,j:j+11);

    end
 end

[Gx, Gy] = imgradientxy(img,'prewitt');
figure
imshowpair(Gx, Gy, 'montage');
 title('Directional Gradients: x-direction, Gx (left), y-direction, Gy (right), using Prewitt method')
axis off;

[Gmag, Gdir] = imgradient(Gx, Gy);
figure
imshowpair(Gmag, Gdir, 'montage')
title('Gradient Magnitude, Gmag (left), and Gradient Direction, Gdir (right), using prewitt method')